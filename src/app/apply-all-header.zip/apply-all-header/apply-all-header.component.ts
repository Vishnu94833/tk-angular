import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-all-header',
  templateUrl: './apply-all-header.component.html',
  styleUrls: ['./apply-all-header.component.scss']
})
export class ApplyAllHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
